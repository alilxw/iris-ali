"""Statistics blueprint package."""
